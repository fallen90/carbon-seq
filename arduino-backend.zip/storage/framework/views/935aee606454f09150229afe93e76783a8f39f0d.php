<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">

    <title>Dashboard - Analytics</title>

    <meta name="viewport" content="width=device-width  , initial-scale=1">
    <meta name="viewport" content="height=device-height, initial-scale=1">

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard/main.css')); ?>">

    <?php echo $__env->yieldContent('substyles'); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.min.js"></script>
</head>

<body class="container-fluid">
    
    <div class="row header">
        <div id="appName" class="col-md-4 col-md-offset-4">
            <span><span class="glyphicon glyphicon-leaf"></span> <?php echo e(env('APP_NAME')); ?></span>
        </div>
    </div>
    <div class="row">
        <div class="col-md-2">
            <span id="txtDashboard">Dashboard</span>
        </div>
    </div>
    <div class="panel panel-success app-panel" id="dashboardMessage">
        <div class="panel-body" id="body">
            <div id="bodyLabel"><span class="glyphicon glyphicon-th-large"></span>   Viewing Options</div>
            <ul class="nav nav-pills" id="viewFrequencyList">
                <li role="presentation" <?php echo e($frequency == 1 ? 'class=active' : ''); ?>><a <?php echo e($frequency != 1 ? 'href='.url('/dashboard?frequency=1') : ''); ?>>Daily</a></li>
                <li role="presentation" <?php echo e((isset($frequency) && $frequency == 2) ? 'class=active' : ''); ?>><a <?php echo e($frequency != 2 ? 'href='.url('/dashboard?frequency=2') : ''); ?>>Weekly</a></li>
                <li role="presentation" <?php echo e((isset($frequency) && $frequency == 3) ? 'class=active' : ''); ?>><a <?php echo e($frequency != 3 ? 'href='.url('/dashboard?frequency=3') : ''); ?>>Monthly</a></li>
            </ul>
        </div>
    </div>
    <div class="panel panel-success app-panel">
        <div class="panel-body">
            <div class="row">
                <div id="colCarbon" class="col-md-4">
                    <span class="chart-title"><span class="glyphicon glyphicon-tree-deciduous"></span>   Carbon Dioxide</span>
                    <?php echo $carbon->render(); ?>

                </div>
                <div id="colHumidity" class="col-md-4">
                    <span class="chart-title"><span class="glyphicon glyphicon-tint"></span>   Humidity</span>
                    <?php echo $humidity->render(); ?>

                </div>
                <div id="colTemperature" class="col-md-4">
                    <span class="chart-title"><span class="glyphicon glyphicon-cloud"></span>   Temperature in C</span>
                    <?php echo $temperature->render(); ?>

                </div>
            </div>
        </div>
    </div>
    <div class="panel panel-success app-panel">
       
        <table class="table table-striped table-bordered">
            <thead>
                <?php if($frequency != 3): ?>
                    <th>Date</th>
                    <th>Time</th>
                <?php else: ?>
                    <th>Month</th>
                <?php endif; ?>
                <th>Arduino No.</th>
                <th>CO2 in PPM</th>
                <th>Humidity</th>
                <th>Temperature (C)</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $arduinodata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if($frequency != 3): ?>
                            <td><?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->created_at)->format('M d, Y')); ?></td>
                            <td><?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->created_at)->format('h:i a')); ?></td>
                        <?php else: ?>
                            <td><?php echo e($item->created_at); ?></td>
                        <?php endif; ?>
                        <td><?php echo e($item->arduino_id); ?></td>
                        <td><?php echo e($item->ppm); ?></td>
                        <td><?php echo e($item->humidity); ?></td>
                        <td><?php echo e($item->temp_in_c); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="server-time">
        <?php echo e('Today is '.Carbon\Carbon::createFromFormat('Y-m-d H:i:s', date('Y-m-d H:i:s'))->format('M d, Y')); ?>

    </div>

    <script src="<?php echo e(asset('js/jquery-3.2.1.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    
    <script>
        // $('#chrCarbon').click(function() {
        //     $('#colCarbon').toggleClass('col-md-4');
        //     $('#colCarbon').toggleClass('col-md-12');
        // });

        // $('#chrHumidity').click(function() {
        //     $('#colHumidity').toggleClass('col-md-4');
        //     $('#colHumidity').toggleClass('col-md-12');
        // });

        // $('#chrTemperature').click(function() {
        //     $('#colTemperature').toggleClass('col-md-4');
        //     $('#colTemperature').toggleClass('col-md-12');
        // });
    </script>

</body>

</html>